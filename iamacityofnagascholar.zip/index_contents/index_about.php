<div class="bg-white" id="vision" data-mdb-container>
  <br>
  <br>
  <br>
  <br>  
  <div class="container">
    <div class="col-md-8 mx-auto">
    <div class="text-center">
      <img class="rounded-circle shadow-2-strong" width="150" alt="vision_icon" src="images/vision.png"
          data-holder-rendered="true">
      <p class="header display-6 pt-3">Vision</p>
      <p class="subtitle">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
      </p>
    </div>
    </div>
  </div>
  <br>
  <br>
  <br>  
</div>
<hr>
<div class="bg-white" id="mission" data-mdb-container>
  <br>
  <br>
  <br>
  <br>  
  <div class="container">
    <div class="col-md-8 mx-auto">
    <div class="text-center">
      <img class="rounded-circle shadow-2-strong" width="150" alt="mission_icon" src="images/mission.png"
          data-holder-rendered="true">
      <p class="header display-6 pt-3">Mission</p>
      <p class="subtitle">
          Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna.
      </p>
    </div>
    </div>
  </div>
  <br>
  <br>
  <br>  
</div>
<hr>
<div class="bg-white" id="objective" data-mdb-container>
  <br>
  <br>
  <br>
  <br>  
  <div class="container">
    <div class="col-md-8 mx-auto">
    <div class="text-center">
      <img class="rounded-circle shadow-2-strong" width="150" alt="objective_icon" src="images/objective.png"
          data-holder-rendered="true">
      <p class="header display-6 pt-3">Objectives</p>
      <p class="subtitle">
          Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus.
Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci.
Aenean nec lorem. In porttitor. Donec laoreet nonummy augue.
Suspendisse dui purus, scelerisque at, vulputate vitae, pretium mattis, nunc. Mauris eget neque at sem venenatis eleifend. Ut nonummy.

      </p>
    </div>
    </div>
  </div>
  <br>
  <br>
  <br>  
</div>