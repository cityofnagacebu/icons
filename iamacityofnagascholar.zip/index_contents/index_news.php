<div class="label bg-light pt-1 text-center"><b>Latest News: </b></div>
<div class="news bg-dark"></div>
<div class="newsText text-light"><p style="font-family: 'Roboto'; z-index: 1;">Acceptance of Applicants for Batch 9 Scholarship Program will be on June 7-30, 2021. </p></div>