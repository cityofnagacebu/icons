<div class="col-md-7 mx-3">
	<div class="row">
		<div class="col-md-7">
			<a class="navbar-brand"><img src="images/icon_brand_logo.png" style="width: 100%; z-index: 2;" alt=""></a>
		</div>
		<div class="col-md-5"></div>
	</div>
			
</div>
<div class="col-md-3 mx-3">
	<div class="row">
		<div class="col-md-5"></div>
		<div class="col-md-7" style="z-index: 3;">
			<a href="application_form.php" style="text-decoration: none;">
			<button type="button" class="btn btn-lg btn-outline-primary btn-block inquire-now">Apply Now</button></a>
		</div>
	</div>		
</div>