<?php 

define('EMAIL', 'info.icons2021@gmail.com');
define('PASSWORD', 'iamacityofnagascholar');

define('DB_HOST', 'fdb33.awardspace.net');
define('DB_USER', '3883786_icons');
define('DB_PASS', 'Mydear-143');
define('DB_NAME', '3883786_icons');